from linkalator import app
import flask
from data_classes import Agent
from util import DataLayer
from cfg import Cfg
import logging

#define the log file and message format
file_handler = logging.FileHandler('app.log')
formatter = logging.Formatter('%(asctime)s | Level: %(levelname)s | Message: %(message)s')
file_handler.setFormatter(formatter)

#initialize our flask app and add logging configuration
app.logger.addHandler(file_handler)
app.logger.setLevel(logging.INFO)

def api_agents():
    dl = DataLayer()
    response = ""
    stat_code = 200
    ld = Cfg().log_detail.format(flask.request.url, flask.request.method, stat_code)

    try:
        if flask.request.method == 'GET':       
            res = dl.execute_select('select aid, aname, city, percent from system.agents order by aid')
            agents = []
            for r in res:
                a = Agent(r[0], r[1], r[2], r[3])
                agents.append(a.__dict__)
            response = flask.jsonify({"agents" : agents})
        elif flask.request.method == 'POST':
            blah = flask.session.get('logged_in')
            #TODO: update agents
            if not flask.session.get('logged_in'):
                flask.session['logged_in'] = True
                response = flask.jsonify({"JSON Message" : "you were just logged in", "original session status" : blah,  "session login status" : flask.session['logged_in']})
            elif flask.session['logged_in']:
                response = flask.jsonify({"JSON Message" : "you were already logged in"})
        app.logger.info(ld)

    except Exception:
        stat_code = 500
        ld = Cfg().log_detail.format(flask.request.url, flask.request.method, stat_code)
        app.logger.exception(ld)
        response = flask.jsonify({"error": "internal server error."})

    finally:
        response.status_code = stat_code
        return response


def site_main():
    return flask.render_template('main.html')


def say_hello(username):
    """Contrived example to demonstrate Flask's url routing capabilities"""
    return 'Hello %s' % username


def show_links():
    dl = DataLayer()
    links = dl.get_links()
    return flask.render_template('show_links.html', links = links)


def show_link_page(page_id):
    if not flask.session.get(Cfg.logged_in):
        flask.session[Cfg.requested_page_id] = page_id
        return flask.redirect(flask.url_for('login'))
    dl = DataLayer()
    links = dl.get_links(int(page_id))
    for l in links:
        app.logger.info('link href: {!s}'.format(l.href))
    return flask.render_template('show_links.html', links = links)


def add_link():
    if not flask.session.get(Cfg.logged_in):
        flask.abort(401)
    dl = DataLayer()
    display_text, href = flask.request.form['title'], flask.request.form['text']
    current_user_id = int(flask.session[Cfg.current_user_id])
    host_page_id = int(flask.session[Cfg.requested_page_id])
    dl.add_link(host_page_id, display_text, href, current_user_id)
    flask.flash('New link was successfully posted')
    return flask.redirect(flask.url_for('show_link_page', page_id = host_page_id))


def remove_link(link_id):
    if not flask.session.get(Cfg.logged_in):
        flask.abort(401)
    dl = DataLayer()
    host_page_id = int(flask.session[Cfg.requested_page_id])
    dl.deactivate_link(int(link_id))
    return flask.redirect(flask.url_for('show_link_page', page_id = host_page_id))


def increment_click(link_id):
    try:
        if not flask.session.get(Cfg.logged_in):
            flask.abort(401)
        dl = DataLayer()
        host_page_id = int(flask.session[Cfg.requested_page_id])
        dl.increment_click_count(link_id)
        return flask.redirect(flask.url_for('show_link_page', page_id = host_page_id))

    except Exception:
        stat_code = 500
        ld = Cfg().log_detail.format(flask.request.url, flask.request.method, stat_code)
        app.logger.exception(ld)


def index():
    pages = []   
    try:        
        dl = DataLayer()
        pages = dl.get_pages()

    except Exception:
        stat_code = 500
        ld = Cfg().log_detail.format(flask.request.url, flask.request.method, stat_code)
        app.logger.exception(ld)

    finally:
        return flask.render_template('index.html', pages = pages)


def statistics():
    users = []
    gateway_totals = []
    top_entry_totals = []
    link_stats = []
    session_users = []
    top_users = []

    try:
        dl = DataLayer()
        stats = dl.get_statistics()
        users = stats['users']
        gateway_totals = stats['gateway_totals']
        top_entry_totals = stats['top_entry_totals']
        link_stats = stats['link_stats']
        session_users = stats['session_users']
        top_users = stats['top_users']

        return flask.render_template('stats.html', users = users, gateway_totals = gateway_totals, \
            top_entry_totals = top_entry_totals, link_stats = link_stats, session_users = session_users, \
            top_users = top_users)

    except Exception:
        stat_code = 500
        ld = Cfg.const_log_detail.format(flask.request.url, flask.request.method, stat_code)
        app.logger.exception(ld)
        return flask.render_template('login.html', error = 'Problem loading page...')


def login():
    error = None
    try:
        if flask.request.method == 'POST':
            user_name = str(flask.request.form[Cfg.username_field])
            password = str(flask.request.form[Cfg.password_field])
            dl = DataLayer()   
            user_id = dl.validate_user(user_name, password)
            if user_id == -1:
                error = 'Invalid password'
                return flask.render_template('login.html', error = error)
            elif user_id == -2:
                error = 'No user record exists for {!s}. Would you like to register?'.format(user_name)
                return flask.render_template('login.html', error = error)
            else:
                flask.session[Cfg.logged_in] = True
                user_id = int(user_id)
                flask.session[Cfg.current_user_id] = user_id
                flask.flash('You were logged in')
                if not flask.session.get(Cfg.requested_page_id):
                    low_page_id = dl.get_lowest_page_id()
                    flask.session[Cfg.requested_page_id] = low_page_id
                    app.logger.info('lowest page id: {!s}'.format(low_page_id))
                    session_id = dl.start_user_session(user_id, low_page_id)
                    flask.session[Cfg.current_session_id] = session_id
                    app.logger.info('user_id: {!s}, requested_page_id: {!s}, session_id: {!s}'\
                        .format(user_id, low_page_id, session_id))
                    return flask.redirect(flask.url_for('index'))  
                else:
                    requested_page_id = int(flask.session[Cfg.requested_page_id])
                    session_id = dl.start_user_session(user_id, requested_page_id)
                    flask.session[Cfg.current_session_id] = session_id
                    app.logger.info('user_id: {!s}, requested_page_id {!s}'.format(user_id, requested_page_id))
                    return dl.get_requested_page(requested_page_id)
        else:
            return flask.render_template('login.html')

    except Exception:
        stat_code = 500
        ld = Cfg().log_detail.format(flask.request.url, flask.request.method, stat_code)
        app.logger.exception(ld)
        return flask.render_template('login.html', error = error)


def logout():
    try:        
        dl = DataLayer()
        dl.end_user_session()
        flask.flash('You were logged out')
        return flask.redirect(flask.url_for('index'))

    except Exception:
        stat_code = 500
        ld = Cfg().log_detail.format(flask.request.url, flask.request.method, stat_code)
        app.logger.exception(ld)


